<?php
// ─── DigiAjo Global — Fetch & Mark Member Notifications ─────────────────────────
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $memberId = $_GET['member_id'] ?? '';
    $email = $_GET['email'] ?? '';
    if (!$memberId && !$email) {
        echo json_encode(['success' => false, 'error' => 'Missing member_id or email']);
        exit;
    }

    $db = getDB();
    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NULL,
                member_id VARCHAR(50) NULL,
                title VARCHAR(255) NOT NULL,
                body TEXT,
                message TEXT,
                kind VARCHAR(50) DEFAULT 'info',
                type VARCHAR(50) DEFAULT 'info',
                audience VARCHAR(50) DEFAULT 'all',
                target_user INT NULL,
                target_plan VARCHAR(50) NULL,
                sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS user_notification_reads (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                notification_id VARCHAR(100) NOT NULL,
                read_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY user_notif (user_id, notification_id)
            )
        ");
        try {
            $db->exec("ALTER TABLE user_notification_reads MODIFY notification_id VARCHAR(100) NOT NULL");
        } catch (Exception $e) {}

        $db->exec("
            CREATE TABLE IF NOT EXISTS user_notification_deletions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                notification_id VARCHAR(100) NOT NULL,
                deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY user_notif_del (user_id, notification_id)
            )
        ");
        try {
            $db->exec("ALTER TABLE user_notification_deletions MODIFY notification_id VARCHAR(100) NOT NULL");
        } catch (Exception $e) {}

        // 1. Get internal user
        $nameParam = $_GET['name'] ?? '';
        $stmt = $db->prepare('SELECT id, member_id, email, name, status, plan_type FROM users WHERE member_id = ? OR id = ? OR email = ? OR name LIKE ? LIMIT 1');
        $stmt->execute([$memberId, is_numeric($memberId) ? (int)$memberId : 0, $email ?: $memberId, "%" . ($nameParam ?: $memberId) . "%"]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            echo json_encode(['success' => false, 'error' => 'User not found']);
            exit;
        }
        
        $userId = (int)$user['id'];
        $userName = $user['name'] ?? '';
        $officialMemberId = $user['member_id'] ?: $memberId;
        $status = $user['status'];
        $planType = $user['plan_type'];

        // ── Auto-sync notifications for all user activities ─────────────────
        // 1. Payments & Savings Submissions/Approvals
        try {
            $payStmt = $db->prepare("
                SELECT id, payment_ref, amount, purpose, status, payment_status, created_at, paid_at 
                FROM payments 
                WHERE user_id = ? OR member_id = ? OR (member_name IS NOT NULL AND member_name != '' AND member_name LIKE ?)
                ORDER BY id DESC
            ");
            $payStmt->execute([$userId, $officialMemberId, "%{$userName}%"]);
            $userPayments = $payStmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($userPayments as $p) {
                $pRef = $p['payment_ref'] ?: ('PAY-' . $p['id']);
                $pStatus = strtolower($p['status'] ?? ($p['payment_status'] ?? 'pending'));
                $pAmount = (float)$p['amount'];
                $pDate = !empty($p['paid_at']) ? $p['paid_at'] : (!empty($p['created_at']) ? $p['created_at'] : date('Y-m-d H:i:s'));
                
                $checkNotif = $db->prepare("
                    SELECT id FROM notifications 
                    WHERE (user_id = ? OR member_id = ?) 
                      AND (body LIKE ? OR message LIKE ?)
                    LIMIT 1
                ");
                $checkNotif->execute([$userId, $officialMemberId, "%{$pRef}%", "%{$pRef}%"]);
                if (!$checkNotif->fetch()) {
                    if ($pStatus === 'approved' || $pStatus === 'confirmed' || $pStatus === 'success') {
                        $nTitle = "Savings Payment Approved";
                        $nBody = "Your contribution of ₦" . number_format($pAmount, 2) . " (Ref: {$pRef}) has been confirmed and credited to your savings balance!";
                        $nKind = "success";
                    } elseif ($pStatus === 'rejected' || $pStatus === 'declined') {
                        $nTitle = "Payment Verification Declined";
                        $nBody = "Your payment submission of ₦" . number_format($pAmount, 2) . " (Ref: {$pRef}) was declined. Please verify your receipt or re-submit.";
                        $nKind = "error";
                    } else {
                        $nTitle = "Savings Payment Submitted";
                        $nBody = "Your savings contribution of ₦" . number_format($pAmount, 2) . " (Ref: {$pRef}) has been received and is pending admin verification.";
                        $nKind = "info";
                    }
                    insert_notification($db, [
                        'user_id'     => $userId,
                        'member_id'   => $officialMemberId,
                        'target_user' => $userId,
                        'audience'    => 'specific_user',
                        'title'       => $nTitle,
                        'body'        => $nBody,
                        'message'     => $nBody,
                        'kind'        => $nKind,
                        'type'        => $nKind,
                        'sent_at'     => $pDate
                    ]);
                }
            }
        } catch (Exception $e) {}

        // 2. Referrals activity
        try {
            $refStmt = $db->prepare("SELECT id, name, member_id, created_at, status FROM users WHERE referred_by = ?");
            $refStmt->execute([$userId]);
            $referrals = $refStmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($referrals as $ref) {
                $refName = $ref['name'];
                $refDate = $ref['created_at'] ?: date('Y-m-d H:i:s');
                $checkRef = $db->prepare("
                    SELECT id FROM notifications 
                    WHERE (user_id = ? OR member_id = ?) 
                      AND (body LIKE ? OR message LIKE ?)
                    LIMIT 1
                ");
                $checkRef->execute([$userId, $officialMemberId, "%{$refName}%", "%{$refName}%"]);
                if (!$checkRef->fetch()) {
                    insert_notification($db, [
                        'user_id'     => $userId,
                        'member_id'   => $officialMemberId,
                        'target_user' => $userId,
                        'audience'    => 'specific_user',
                        'title'       => '🎉 New Referral Joined!',
                        'body'        => "{$refName} registered on DigiAjo Global using your personal referral link.",
                        'message'     => "{$refName} registered on DigiAjo Global using your personal referral link.",
                        'kind'        => 'referral',
                        'type'        => 'referral',
                        'sent_at'     => $refDate
                    ]);
                }
            }
        } catch (Exception $e) {}

        // 3. Welcome / Account Status
        try {
            $checkWelcome = $db->prepare("
                SELECT id FROM notifications 
                WHERE (user_id = ? OR member_id = ?) 
                  AND (title LIKE '%Welcome to DigiAjo%' OR title LIKE '%Account Approved%')
                LIMIT 1
            ");
            $checkWelcome->execute([$userId, $officialMemberId]);
            if (!$checkWelcome->fetch()) {
                insert_notification($db, [
                    'user_id'     => $userId,
                    'member_id'   => $officialMemberId,
                    'target_user' => $userId,
                    'audience'    => 'specific_user',
                    'title'       => 'Welcome to DigiAjo Global',
                    'body'        => "Your member account ({$officialMemberId}) is active on the {$planType} plan. Manage your weekly contributions and track your savings milestones right here.",
                    'message'     => "Your member account ({$officialMemberId}) is active on the {$planType} plan. Manage your weekly contributions and track your savings milestones right here.",
                    'kind'        => 'success',
                    'type'        => 'success',
                    'sent_at'     => !empty($user['created_at']) ? $user['created_at'] : date('Y-m-d H:i:s')
                ]);
            }
        } catch (Exception $e) {}

        // 4. Savings milestone notices
        try {
            $curSaved = (float)($user['saved'] ?? 0);
            $curWeeks = (int)($user['weeks'] ?? 0);
            if ($curWeeks > 0 || $curSaved > 0) {
                $checkMilestone = $db->prepare("
                    SELECT id FROM notifications 
                    WHERE (user_id = ? OR member_id = ?) 
                      AND title LIKE '%Savings Plan Milestone%'
                    LIMIT 1
                ");
                $checkMilestone->execute([$userId, $officialMemberId]);
                if (!$checkMilestone->fetch()) {
                    insert_notification($db, [
                        'user_id'     => $userId,
                        'member_id'   => $officialMemberId,
                        'target_user' => $userId,
                        'audience'    => 'specific_user',
                        'title'       => 'Savings Plan Milestone',
                        'body'        => "You have reached Week {$curWeeks} with a total of ₦" . number_format($curSaved, 2) . " saved on your Double-Up plan. Keep going towards Week 50!",
                        'message'     => "You have reached Week {$curWeeks} with a total of ₦" . number_format($curSaved, 2) . " saved on your Double-Up plan. Keep going towards Week 50!",
                        'kind'        => 'success',
                        'type'        => 'success',
                        'sent_at'     => date('Y-m-d H:i:s')
                    ]);
                }
            }
        } catch (Exception $e) {}

        // 2. Fetch relevant notifications safely (excluding deleted ones)
        ensure_notifications_schema($db);
        $cols = $db->query("SHOW COLUMNS FROM notifications")->fetchAll(PDO::FETCH_COLUMN);
        $colNames = array_map('strtolower', $cols);

        $bodyExpr = in_array('body', $colNames) && in_array('message', $colNames)
            ? "COALESCE(NULLIF(n.body, ''), n.message, '')"
            : (in_array('body', $colNames) ? "COALESCE(n.body, '')" : (in_array('message', $colNames) ? "COALESCE(n.message, '')" : "''"));

        $kindExpr = in_array('kind', $colNames) && in_array('type', $colNames)
            ? "COALESCE(NULLIF(n.kind, ''), n.type, 'info')"
            : (in_array('kind', $colNames) ? "COALESCE(n.kind, 'info')" : (in_array('type', $colNames) ? "COALESCE(n.type, 'info')" : "'info'"));

        $sentExpr = in_array('sent_at', $colNames) && in_array('created_at', $colNames)
            ? "COALESCE(n.sent_at, n.created_at, NOW())"
            : (in_array('sent_at', $colNames) ? "COALESCE(n.sent_at, NOW())" : "NOW()");

        $query = "
            SELECT n.id, n.title, 
                   {$bodyExpr} as body, 
                   {$kindExpr} as kind, 
                   {$sentExpr} as sent_at,
                   IF(r.read_at IS NULL, 1, 0) as is_unread
            FROM notifications n
            LEFT JOIN user_notification_reads r ON (CAST(n.id AS CHAR) = r.notification_id OR n.id = r.notification_id) AND r.user_id = ?
            LEFT JOIN user_notification_deletions d ON (CAST(n.id AS CHAR) = d.notification_id OR n.id = d.notification_id) AND d.user_id = ?
            WHERE d.id IS NULL
              AND (
                   n.audience = 'all'
                OR n.audience IS NULL
                OR n.audience = ''
                OR (n.audience = 'active_members' AND ? = 'active')
                OR (n.audience = 'specific_user' AND n.target_user = ?)
                OR n.user_id = ?
                OR (n.member_id IS NOT NULL AND (n.member_id = ? OR n.member_id = ?))
                OR (n.audience = 'plan_type' AND n.target_plan = ?)
              )
            ORDER BY {$sentExpr} DESC, n.id DESC
            LIMIT 50
        ";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            $userId,
            $userId,
            $status,
            $userId,
            $userId,
            $memberId,
            $officialMemberId,
            $planType
        ]);
        
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Count unread
        $unreadCount = 0;
        foreach ($notifications as $n) {
            if ($n['is_unread'] == 1) $unreadCount++;
        }

        echo json_encode([
            'success' => true,
            'unreadCount' => $unreadCount,
            'notifications' => $notifications
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $memberId = $input['member_id'] ?? '';
    $action = $input['action'] ?? '';
    $notificationId = $input['notification_id'] ?? $input['delete_id'] ?? null;

    if (!$memberId) {
        echo json_encode(['success' => false, 'error' => 'Missing member_id']);
        exit;
    }

    $db = getDB();
    try {
        $stmt = $db->prepare('SELECT id FROM users WHERE member_id = ? OR id = ? OR email = ? LIMIT 1');
        $stmt->execute([$memberId, is_numeric($memberId) ? (int)$memberId : 0, $memberId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) {
            echo json_encode(['success' => false, 'error' => 'User not found']);
            exit;
        }
        $userId = (int)$user['id'];

        if ($action === 'delete' || !empty($input['delete_id'])) {
            if ($notificationId) {
                $stmt = $db->prepare('INSERT IGNORE INTO user_notification_deletions (user_id, notification_id) VALUES (?, ?)');
                $stmt->execute([$userId, $notificationId]);
            }
        } elseif ($action === 'clear_all' || (!empty($input['clear_all']) && empty($notificationId))) {
            $stmt = $db->prepare("
                INSERT IGNORE INTO user_notification_deletions (user_id, notification_id)
                SELECT ?, id FROM notifications
            ");
            $stmt->execute([$userId]);
        } else {
            // Default: Mark as read
            if ($notificationId) {
                $stmt = $db->prepare('INSERT IGNORE INTO user_notification_reads (user_id, notification_id) VALUES (?, ?)');
                $stmt->execute([$userId, $notificationId]);
            } else {
                $stmt = $db->prepare("
                    INSERT IGNORE INTO user_notification_reads (user_id, notification_id)
                    SELECT ?, id FROM notifications
                ");
                $stmt->execute([$userId]);
            }
        }

        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
    exit;
}
